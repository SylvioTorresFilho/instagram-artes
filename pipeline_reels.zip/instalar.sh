#!/bin/bash
# Prepara a producao dos reels numa maquina nova (sessao agendada). Idempotente.
set -e
AQUI="$(cd "$(dirname "$0")" && pwd)"
cd "$AQUI/r3d" && [ -d node_modules/three ] || npm install three@0.170.0 --silent
pip install --break-system-packages -q kokoro-onnx soundfile pillow playwright >/dev/null 2>&1 || true
cd "$AQUI/tts"
[ -f kokoro-v1.0.onnx ] || curl -sSfL -o kokoro-v1.0.onnx https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0/kokoro-v1.0.onnx
[ -f voices-v1.0.bin ] || curl -sSfL -o voices-v1.0.bin https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0/voices-v1.0.bin
CH=$(ls -d /opt/pw-browsers/chromium-*/chrome-linux64/chrome 2>/dev/null | head -1)
[ -n "$CH" ] && sed -i "s#executable_path='[^']*'#executable_path='$CH'#" "$AQUI/r3d/render.py"
echo "pipeline pronto"
