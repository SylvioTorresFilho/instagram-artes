"""Camadas transparentes do reel (1080x1920): base fixa (logomarca, selo, contatos,
assinatura) e uma camada de texto por fase.
Uso: python3 overlay_reel.py config.json pasta_saida
config: {"chip": "...", "fases": [{"titulo": "...", "texto": "..."}, ...], "acento": [r,g,b]}
"""
import json, os, sys
from PIL import Image, ImageDraw, ImageFont, ImageFilter

AQUI = os.path.dirname(os.path.abspath(__file__))
FONTES = os.path.join(AQUI, "fonts")
W, H = 1080, 1920
OURO = (226, 182, 74)
BRANCO = (255, 255, 255)
CONTATOS = [
    ("ESCRITÓRIO VIRTUAL", "+55 83 99828-8100 (só mensagens)"),
    ("WHATSAPP", "+55 83 99970-1000"),
    ("INSTAGRAM", "@sylviotorres.oficial"),
    ("SITE", "www.stfadvogados.adv.br"),
    ("E-MAIL", "sylviotorresfilho@gmail.com"),
]


def F(tam, peso, nome="Montserrat"):
    f = ImageFont.truetype(os.path.join(FONTES, nome + ".ttf"), tam)
    f.set_variation_by_axes([peso])
    return f


def quebrar(d, txt, f, larg):
    out, cur = [], ""
    for p in txt.split():
        t = (cur + " " + p).strip()
        if d.textlength(t, font=f) <= larg:
            cur = t
        else:
            out.append(cur); cur = p
    if cur:
        out.append(cur)
    return out


def texto_sombra(img, xy, txt, f, cor, raio=6):
    s = Image.new("RGBA", img.size, (0, 0, 0, 0))
    ImageDraw.Draw(s).text(xy, txt, font=f, fill=(0, 0, 0, 230))
    img.alpha_composite(s.filter(ImageFilter.GaussianBlur(raio)))
    ImageDraw.Draw(img).text(xy, txt, font=f, fill=cor)


def selo(diam, acento):
    s = Image.new("RGBA", (diam, diam), (0, 0, 0, 0))
    d = ImageDraw.Draw(s)
    d.ellipse((0, 0, diam - 1, diam - 1), fill=(8, 8, 10, 240), outline=OURO, width=6)
    d.ellipse((13, 13, diam - 14, diam - 14), outline=acento, width=3)
    linhas = [("ATUAÇÃO EM", 16, 700, BRANCO), ("TODO O", 20, 800, BRANCO), ("BRASIL", 32, 900, OURO),
              ("ATENDIMENTO", 14, 700, BRANCO), ("24 HORAS", 22, 900, OURO)]
    alts = [F(t, p).getbbox("Ag")[3] + 5 for _, t, p, _ in linhas]
    y = (diam - sum(alts)) / 2
    for (txt, t, p, c), a in zip(linhas, alts):
        f = F(t, p)
        d.text(((diam - d.textlength(txt, font=f)) / 2, y), txt, font=f, fill=c)
        y += a
    return s


def base(cfg, saida):
    acento = tuple(cfg.get("acento", [170, 18, 28]))
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    # degradês de leitura
    g = Image.new("L", (W, H), 0)
    gd = ImageDraw.Draw(g)
    for y in range(H):
        if y < 960:
            v = int(235 * max(0, 1 - y / 960) ** 0.8)
        elif y > 1220:
            v = int(245 * min(1, (y - 1220) / 260))
        else:
            v = 0
        gd.line((0, y, W, y), fill=v)
    img = Image.composite(Image.new("RGBA", (W, H), (0, 0, 0, 255)), img, g)
    d = ImageDraw.Draw(img)
    d.rectangle((0, 0, W, 10), fill=acento)
    # logomarca em destaque
    logo = Image.open(os.path.join(AQUI, "logo_ss_torres_3d.png")).convert("RGBA")
    alt = 480
    logo = logo.resize((int(logo.width * alt / logo.height), alt), Image.LANCZOS)
    pad = 90
    am = Image.new("L", (logo.width + 2 * pad, logo.height + 2 * pad), 0)
    am.paste(logo.split()[3], (pad, pad))
    halo = Image.new("RGBA", am.size, (255, 190, 80, 0))
    halo.putalpha(am.filter(ImageFilter.GaussianBlur(30)).point(lambda v: int(v * 0.40)))
    px = (W - logo.width) // 2
    img.alpha_composite(halo, (px - pad, 110 - pad))
    img.alpha_composite(logo, (px, 110))
    # selo
    sl = selo(220, acento)
    img.alpha_composite(sl, (W - 220 - 34, 150))
    # contatos
    d = ImageDraw.Draw(img)
    topo = 1335
    d.rounded_rectangle((34, topo, W - 34, topo + 300), radius=24, fill=(6, 6, 8, 235), outline=OURO, width=3)
    fr, fv = F(21, 800), F(29, 600)
    y = topo + 26
    for r, v in CONTATOS:
        d.text((64, y + 6), r, font=fr, fill=OURO)
        d.text((350, y), v, font=fv, fill=BRANCO)
        y += 53
    # assinatura com medalhão
    med = Image.open(os.path.join(AQUI, "medalhao.png")).convert("RGBA").resize((96, 96), Image.LANCZOS)
    d.rectangle((0, topo + 318, W, topo + 418), fill=acento + (255,))
    img.alpha_composite(med, (40, topo + 320))
    fa = F(27, 800)
    ass = "Dr. Sylvio Torres Filho — Advogado — OAB/PB 3613"
    d.text((150 + (W - 190 - d.textlength(ass, font=fa)) / 2, topo + 350), ass, font=fa, fill=BRANCO)
    img.save(saida)


def fase(cfg, i, saida):
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    pn = Image.new("L", (W, H), 0)
    ImageDraw.Draw(pn).rounded_rectangle((40, 620, W - 40, 1010), radius=40, fill=170)
    img = Image.composite(Image.new("RGBA", (W, H), (0, 0, 0, 255)), img, pn.filter(ImageFilter.GaussianBlur(30)))
    d = ImageDraw.Draw(img)
    fz = cfg["fases"][i]
    larg = 960
    fc = F(27, 800)
    chip = fz.get("chip", cfg["chip"]).upper()
    wc = d.textlength(chip, font=fc) + 48
    y = 640
    d.rounded_rectangle(((W - wc) / 2, y, (W + wc) / 2, y + 52), radius=26, fill=tuple(cfg.get("acento", [170, 18, 28])) + (255,))
    d.text(((W - wc) / 2 + 24, y + 11), chip, font=fc, fill=BRANCO)
    y += 78
    ft = F(fz.get("tam", 54), 900)
    for ln in quebrar(d, fz["titulo"], ft, larg):
        texto_sombra(img, ((W - d.textlength(ln, font=ft)) / 2, y), ln, ft, BRANCO)
        y += int(fz.get("tam", 54) * 1.18)
    if fz.get("texto"):
        y += 10
        fs = F(34, 600)
        for ln in quebrar(d, fz["texto"], fs, larg):
            texto_sombra(img, ((W - d.textlength(ln, font=fs)) / 2, y), ln, fs, (255, 233, 190))
            y += 44
    img.save(saida)


if __name__ == "__main__":
    cfg = json.load(open(sys.argv[1], encoding="utf-8"))
    out = sys.argv[2]
    os.makedirs(out, exist_ok=True)
    base(cfg, os.path.join(out, "base.png"))
    for i in range(len(cfg["fases"])):
        fase(cfg, i, os.path.join(out, f"fase{i}.png"))
