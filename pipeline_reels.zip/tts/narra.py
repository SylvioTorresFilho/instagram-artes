import sys, soundfile as sf
from kokoro_onnx import Kokoro
k = Kokoro("kokoro-v1.0.onnx", "voices-v1.0.bin")
print([v for v in k.get_voices() if v.startswith('p')])
texto = open(sys.argv[1], encoding='utf-8').read().strip()
voz = sys.argv[3] if len(sys.argv) > 3 else 'pf_dora'
amostras, sr = k.create(texto, voice=voz, speed=1.0, lang="pt-br")
sf.write(sys.argv[2], amostras, sr)
print(len(amostras)/sr, 's')
