#!/bin/bash
# Uso: montar_reel.sh pasta_frames fps_frames camadas voz.wav t1 t2 saida.mp4
set -e
FR=$1; FPS=$2; CAM=$3; VOZ=$4; T1=$5; T2=$6; OUT=$7
DUR=$(python3 -c "import soundfile as sf;i=sf.info('$VOZ');print(round(i.duration+0.8,2))")
# trilha ambiente suave sintetizada (sem direitos autorais de terceiros)
ffmpeg -y -loglevel error -f lavfi -i "sine=frequency=110:duration=$DUR" -f lavfi -i "sine=frequency=164.81:duration=$DUR" \
  -f lavfi -i "sine=frequency=220:duration=$DUR" -f lavfi -i "sine=frequency=329.63:duration=$DUR" \
  -filter_complex "[0][1][2][3]amix=inputs=4,tremolo=f=0.25:d=0.5,lowpass=f=900,volume=0.10,afade=t=in:d=2,afade=t=out:st=$(python3 -c "print($DUR-2)"):d=2[a]" \
  -map "[a]" -ar 44100 trilha.wav
ffmpeg -y -loglevel error -i "$VOZ" -i trilha.wav -filter_complex "[0]adelay=400|400,volume=1.6[v];[v][1]amix=inputs=2:duration=longest:normalize=0,alimiter=limit=0.95[a]" -map "[a]" -ar 44100 audio_mix.wav
ffmpeg -y -loglevel error -framerate $FPS -i "$FR/f%05d.jpg" -loop 1 -i "$CAM/base.png" -loop 1 -i "$CAM/fase0.png" -loop 1 -i "$CAM/fase1.png" -loop 1 -i "$CAM/fase2.png" -i audio_mix.wav \
  -filter_complex "[0]framerate=fps=30,format=yuva420p,trim=duration=$DUR[bg]; \
  [2]format=rgba,fade=t=in:st=0.2:d=0.6:alpha=1,fade=t=out:st=$(python3 -c "print($T1-0.5)"):d=0.5:alpha=1[f0]; \
  [3]format=rgba,fade=t=in:st=$T1:d=0.6:alpha=1,fade=t=out:st=$(python3 -c "print($T2-0.5)"):d=0.5:alpha=1[f1]; \
  [4]format=rgba,fade=t=in:st=$T2:d=0.6:alpha=1[f2]; \
  [bg][1]overlay=shortest=0[b1];[b1][f0]overlay[b2];[b2][f1]overlay[b3];[b3][f2]overlay,format=yuv420p,trim=duration=$DUR[v]" \
  -map "[v]" -map 5:a -c:v libx264 -preset veryfast -crf 20 -r 30 -c:a aac -b:a 160k -movflags +faststart -t $DUR "$OUT"
echo "ok $OUT $DUR"
