# Producao diaria de reels - @sylviotorres.oficial

1. bash instalar.sh
2. Escrever roteiro.json (ver produzir_dia.py)
3. python3 produzir_dia.py roteiro.json saida/
Voz: pf_dora (Kokoro, feminina, pt-BR). Video 1080x1920, 30 fps. Logomarca SS TORRES, selo
"Atuacao em todo o Brasil - Atendimento 24 horas", contatos oficiais e assinatura OAB/PB 3613.
