# Producao diaria de reels - @sylviotorres.oficial (versao de 25/10/2026)

VOZ (no Mac, internet livre, pela ferramenta de comandos do Mac):
  ~/.jurisuniversal_voz/venv/bin/edge-tts --voice pt-BR-ThalitaMultilingualNeural --rate=+6% \
     --text "<narracao>" --write-media ~/Desktop/"A - INSTAGRAM DIARIO/_VOZ/<data>_seg.mp3"
  (Francisca: pt-BR-FranciscaNeural. Voz do Dr. Sylvio: so com amostra aprovada por ele; NUNCA com a imagem dele.)
PRODUCAO (nuvem):
  SEM_KOKORO=1 bash instalar.sh
  roteiro.json com "voz_arquivo" apontando para o mp3 de cada reel
  python3 conferir_publicidade.py  -> use conferir_publicidade(texto) na narracao e na legenda: BLOQUEIO impede publicar
  python3 produzir_dia.py roteiro.json saida/
Video 1080x1920, 30 fps; pausas da voz encurtadas; logomarca, selo, contatos e assinatura "Dr. Sylvio Torres Filho — Advogado" (sem o numero da OAB, por ordem do titular em 25/10/2026).
