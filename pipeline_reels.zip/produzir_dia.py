"""Producao diaria dos dois reels (seguidores e teste para nao seguidores).

Uso:  python3 produzir_dia.py roteiro.json pasta_saida
roteiro.json:
{
  "data": "2026-10-26", "cena": "motorista|internacional|familia|consumidor|bancos|trabalho|geral",
  "acento": [170,18,28], "chip": "Previdenciário · STJ",
  "seguidores": {"narracao": "...", "fases": [{"titulo":"...","texto":"...","tam":54}, x3]},
  "teste":      {"narracao": "...", "fases": [ ... 3 fases ... ]}
}
Saida: reel_seguidores.mp4, reel_teste.mp4, capa_seguidores.jpg, capa_teste.jpg
Requisitos (instalados por instalar.sh): three (npm), kokoro-onnx + soundfile (pip), modelos kokoro,
ffmpeg, Chromium do Playwright.
"""
import json, os, subprocess, sys, shutil

AQUI = os.path.dirname(os.path.abspath(__file__))


def sh(cmd, **kw):
    print("+", " ".join(cmd) if isinstance(cmd, list) else cmd, flush=True)
    subprocess.run(cmd, check=True, **kw)


def main(roteiro, saida):
    R = json.load(open(roteiro, encoding="utf-8"))
    os.makedirs(saida, exist_ok=True)
    frames = os.path.join(saida, "_frames")
    duracoes = {}
    # 1) narracoes (voz feminina neural pf_dora, velocidade normal)
    for qual in ("seguidores", "teste"):
        txt = os.path.join(saida, "_narr_%s.txt" % qual)
        open(txt, "w", encoding="utf-8").write(R[qual]["narracao"])
        wav = os.path.join(saida, "_voz_%s.wav" % qual)
        sh([sys.executable, os.path.join(AQUI, "tts", "narra.py"), txt, wav, "pf_dora"], cwd=os.path.join(AQUI, "tts"))
        import soundfile as sf
        duracoes[qual] = sf.info(wav).duration
    dur = max(duracoes.values()) + 1.2
    # 2) cena 3D (12 quadros/s, interpolados para 30 na montagem)
    if os.path.isdir(frames):
        shutil.rmtree(frames)
    sh([sys.executable, os.path.join(AQUI, "r3d", "render.py"), R.get("cena", "geral"), str(round(dur, 1)), "12", frames],
       cwd=os.path.join(AQUI, "r3d"))
    # 3) camadas e montagem
    for qual in ("seguidores", "teste"):
        cfg = {"chip": R.get("chip", ""), "acento": R.get("acento", [170, 18, 28]), "fases": R[qual]["fases"]}
        cj = os.path.join(saida, "_cfg_%s.json" % qual)
        json.dump(cfg, open(cj, "w", encoding="utf-8"), ensure_ascii=False)
        cam = os.path.join(saida, "_camadas_%s" % qual)
        sh([sys.executable, os.path.join(AQUI, "overlay_reel.py"), cj, cam])
        d = duracoes[qual]
        t1, t2 = round(d * 0.30, 1), round(d * 0.68, 1)
        out = os.path.join(saida, "reel_%s.mp4" % qual)
        sh(["bash", os.path.join(AQUI, "montar_reel.sh"), frames, "12", cam, os.path.join(saida, "_voz_%s.wav" % qual),
            str(t1), str(t2), out], cwd=saida)
        sh(["ffmpeg", "-y", "-loglevel", "error", "-ss", str(round(d * 0.45, 1)), "-i", out, "-frames:v", "1", "-q:v", "2",
            os.path.join(saida, "capa_%s.jpg" % qual)])
    print("PRONTO", saida)


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
