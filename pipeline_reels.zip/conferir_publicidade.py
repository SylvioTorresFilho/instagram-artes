# -*- coding: utf-8 -*-
"""JURISUNIVERSAL 4.0 - r230a (25/10/2026): NARRACAO HUMANA, CONFERENCIA DA PUBLICIDADE (PROVIMENTO 205)
E CALCULADORAS PARA O CLIENTE.

Pedido do titular (25/10/2026): voz humana, direta, sem pausas de robo; voz feminina bonita, clara e firme;
em alguns videos, a voz dele (nunca a imagem dele). Incrementar o programa com as inovacoes do mercado.

1. NARRACAO (rota v2/r230/narrar). Roda NO MAC, onde a internet e livre. Ordem dos provedores:
   a) voz do titular clonada (Chatterbox, licenca MIT), se instalada por "A - INSTALAR A VOZ CLONADA.command"
      e houver amostra em _VOZ/amostra_titular.wav - somente quando pedida (voz="titular");
   b) Azure Neural (chave em config/azure_tts.key, regiao em config/azure_tts_regiao.txt) - Francisca ou Thalita;
   c) Google Cloud Chirp 3 HD (chave em config/google_tts.key);
   d) voz neural Thalita (Microsoft), instalada em ~/.jurisuniversal_voz (padrao atual, sem chave);
   e) voz feminina do Google (sem chave), ultimo recurso.
   Saida: Mesa/A - INSTAGRAM DIARIO/_VOZ/<nome>.mp3 (ou .wav). O tratamento final (pausas curtas, volume,
   presenca) e feito pela producao dos reels.
2. CONFERENCIA DA PUBLICIDADE (rota v2/r230/publicidade). Antes de qualquer post, legenda ou roteiro: barra
   preco e honorarios, promessa de resultado, "comente X que eu envio", autoengrandecimento, comparacao,
   sensacionalismo e caso concreto identificavel. Base: Provimento CFOAB 205/2021 e o capitulo da publicidade
   do Codigo de Etica e Disciplina. E um alerta de conferencia: a decisao final e do advogado.
3. CALCULADORAS (rota v2/r230/calcular): rescisao CLT (estimativa), renda per capita do BPC/LOAS e prazo
   prescricional trabalhista. Informativas, com o aviso de que cada caso exige analise.
Somente biblioteca padrao.
"""
import datetime
import json
import os
import re
import subprocess
import urllib.parse
import urllib.request

try:
    import base40
except ImportError:          # fora do Mac (producao na nuvem): so a conferencia e usada
    base40 = None

PASTA_VOZ = os.path.expanduser("~/Desktop/A - INSTAGRAM DIARIO/_VOZ")
SALARIO_MINIMO_PADRAO = 1621.00   # 2026 (decreto publicado em dez/2025); ajuste r230_salario_minimo
UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130 Safari/537.36"


# ============================================================================ 1. narracao

def _frases(texto, limite=190):
    out = []
    for s in re.findall(r"[^.?!;]+[.?!;]?", texto or ""):
        x = s.strip()
        while len(x) > limite:
            i = x.rfind(",", 0, limite)
            i = i + 1 if i > 50 else x.rfind(" ", 0, limite)
            out.append(x[:i].strip())
            x = x[i:].strip()
        if x:
            out.append(x)
    return out


def _http(url, dados=None, cab=None, tempo=40):
    req = urllib.request.Request(url, data=dados, headers=dict({"User-Agent": UA}, **(cab or {})))
    with urllib.request.urlopen(req, timeout=tempo) as r:
        return r.read()


def _chave(nome):
    try:
        return base40.ler_chave(nome)
    except Exception:
        return None


def _azure(texto, voz):
    k = _chave("azure_tts")
    if not k:
        return None
    reg = (_chave("azure_tts_regiao") or "brazilsouth").strip()
    voz = voz if voz and "Neural" in voz else "pt-BR-FranciscaNeural"
    esc = texto.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    ssml = ("<speak version='1.0' xml:lang='pt-BR'><voice name='%s'><prosody rate='+4%%'>%s</prosody></voice></speak>"
            % (voz, esc)).encode("utf-8")
    return _http("https://%s.tts.speech.microsoft.com/cognitiveservices/v1" % reg, ssml,
                 {"Ocp-Apim-Subscription-Key": k, "Content-Type": "application/ssml+xml",
                  "X-Microsoft-OutputFormat": "audio-24khz-96kbitrate-mono-mp3"}), "mp3"


def _google_cloud(texto, voz):
    k = _chave("google_tts")
    if not k:
        return None
    import base64
    corpo = json.dumps({"input": {"text": texto},
                        "voice": {"languageCode": "pt-BR", "name": voz if voz and voz.startswith("pt-BR-") else "pt-BR-Chirp3-HD-Aoede"},
                        "audioConfig": {"audioEncoding": "MP3", "speakingRate": 1.04}}).encode("utf-8")
    r = json.loads(_http("https://texttospeech.googleapis.com/v1/text:synthesize?key=" + urllib.parse.quote(k), corpo,
                         {"Content-Type": "application/json"}))
    return base64.b64decode(r["audioContent"]), "mp3"


def _edge(texto, voz):
    """Voz neural da Microsoft (Thalita Multilingual ou Francisca), instalada em ~/.jurisuniversal_voz."""
    exe = os.path.expanduser("~/.jurisuniversal_voz/venv/bin/edge-tts")
    if not os.path.exists(exe):
        return None
    nome = {"francisca": "pt-BR-FranciscaNeural", "antonio": "pt-BR-AntonioNeural"}.get((voz or "").lower(),
                                                                                       "pt-BR-ThalitaMultilingualNeural")
    os.makedirs(PASTA_VOZ, exist_ok=True)
    tmp = os.path.join(PASTA_VOZ, "_tmp_edge.mp3")
    subprocess.run([exe, "--voice", nome, "--rate=+6%", "--text", texto, "--write-media", tmp], check=True, timeout=300,
                   capture_output=True)
    return open(tmp, "rb").read(), "mp3"


def _google_livre(texto, voz=None):
    partes = []
    for f in _frases(texto):
        u = ("https://translate.google.com/translate_tts?ie=UTF-8&tl=pt-BR&client=tw-ob&ttsspeed=1&q="
             + urllib.parse.quote(f))
        partes.append(_http(u))
    return b"".join(partes), "mp3"


def _clonada(texto, voz=None):
    """Voz do titular clonada localmente (Chatterbox). So roda se o instalador tiver sido executado."""
    py = os.path.expanduser("~/.jurisuniversal_voz/venv/bin/python")
    script = os.path.join(os.path.dirname(os.path.abspath(__file__)), "voz_clonada_r230.py")
    amostra = os.path.join(PASTA_VOZ, "amostra_titular.wav")
    if not (os.path.exists(py) and os.path.exists(script) and os.path.exists(amostra)):
        return None
    saida = os.path.join(PASTA_VOZ, "_tmp_clonada.wav")
    subprocess.run([py, script, amostra, saida], input=texto.encode("utf-8"), check=True, timeout=900)
    return open(saida, "rb").read(), "wav"


def provedores():
    return {"titular_clonada": os.path.exists(os.path.expanduser("~/.jurisuniversal_voz/venv/bin/python"))
                               and os.path.exists(os.path.join(PASTA_VOZ, "amostra_titular.wav")),
            "azure": bool(_chave("azure_tts")), "google_cloud": bool(_chave("google_tts")),
            "neural_thalita": os.path.exists(os.path.expanduser("~/.jurisuniversal_voz/venv/bin/edge-tts")),
            "google_livre": True}


def narrar(c, u=None):
    texto = (c.get("texto") or "").strip()
    if not texto:
        raise ValueError("Informe o texto da narração.")
    if len(texto) > 4000:
        raise ValueError("Texto longo demais para uma narração (máximo de 4.000 caracteres).")
    nome = re.sub(r"[^A-Za-z0-9_-]", "_", c.get("nome") or "narracao")[:60]
    voz = (c.get("voz") or "feminina").strip()
    ordem = ([_clonada] if voz == "titular" else []) + [_azure, _google_cloud, _edge, _google_livre]
    erros = []
    for f in ordem:
        try:
            r = f(texto, voz)
        except Exception as e:
            erros.append("%s: %s" % (f.__name__.strip("_"), str(e)[:160]))
            continue
        if r:
            dados, ext = r
            os.makedirs(PASTA_VOZ, exist_ok=True)
            caminho = os.path.join(PASTA_VOZ, "%s.%s" % (nome, ext))
            open(caminho, "wb").write(dados)
            return {"ok": True, "arquivo": caminho, "provedor": f.__name__.strip("_"), "bytes": len(dados),
                    "avisos": erros}
    if voz == "titular":
        erros.insert(0, "voz do titular ainda não instalada ou sem amostra")
    raise ValueError("Não foi possível narrar: " + "; ".join(erros))


# ============================================================================ 2. conferencia da publicidade

REGRAS = [
    ("BLOQUEIO", "preço ou honorários", r"r\$\s*\d|honor[aá]rios?\s+(de|a partir|por apenas|fixos)|valor da consulta|consulta (gr[aá]tis|gratuita)|\bdesconto\b|parcel(a|amos)|promo[cç][aã]o",
     "Publicidade da advocacia não pode divulgar valores, gratuidade, descontos ou formas de pagamento."),
    ("BLOQUEIO", "promessa de resultado", r"garant(ido|imos|ia de)|\b100\s?%|ganh(e|amos|ar) (sua|a) (causa|a[cç][aã]o)|vai receber|voc[eê] tem direito a receber|resultado certo|sem risco|causa ganha",
     "Não se promete resultado nem se afirma direito no caso concreto."),
    ("BLOQUEIO", "captação ativa", r"coment[ae]\s+[\"'“]?[A-Z]{3,}|comenta\s+[\"'“]?[A-Z]{3,}|que eu (te )?(envio|mando)|chama no direct agora|clique e ganhe|[uú]ltimas vagas",
     "\"Comente X que eu envio\" e convites agressivos são tratados como captação de clientela."),
    ("ALERTA", "autoengrandecimento ou comparação", r"o melhor advogado|melhor escrit[oó]rio|n[uú]mero 1|n[º°]\s?1|mais barato|[uú]nico (advogado|escrit[oó]rio)|imbat[ií]vel|especialista em tudo",
     "Expressões de autoengrandecimento e comparação com colegas são vedadas."),
    ("ALERTA", "título de especialista", r"\bespecialista\b",
     "\"Especialista\" só com o título formal comprovado; prefira \"atua em\"."),
    ("ALERTA", "sensacionalismo", r"!!+|urgente!|chocante|absurdo|escândalo|ningu[eé]m te conta|segredo que",
     "Tom sensacionalista contraria a discrição e a sobriedade exigidas."),
    ("ALERTA", "caso concreto identificável", r"\bmeu cliente\b|\bminha cliente\b|\bganhamos\b|processo n[ºo°]?\s?\d{7}",
     "Não se divulga caso de cliente, vitória em processo ou número de processo em publicidade."),
    ("ALERTA", "atendimento como consulta", r"tire suas d[uú]vidas (jur[ií]dicas )?(gr[aá]tis|agora)|respondo (todas as )?d[uú]vidas",
     "Robô e mensagens não podem dar consulta jurídica a quem ainda não é cliente; ofereça agendamento."),
]


def conferir_publicidade(texto):
    t = texto or ""
    achados = []
    for nivel, nome, padrao, porque in REGRAS:
        for m in re.finditer(padrao, t, flags=re.I):
            ini = max(0, m.start() - 40)
            achados.append({"nivel": nivel, "regra": nome, "trecho": t[ini:m.end() + 40].replace("\n", " "),
                            "porque": porque})
            break
    maius = sum(1 for p in re.findall(r"\b[A-ZÁÉÍÓÚÂÊÔÃÕÇ]{4,}\b", t) if p not in ("STJ", "STF", "TST", "CNJ", "OAB", "INSS", "CLT", "FGTS", "BPC", "LOAS", "TEA", "ANS", "CPC", "CDC", "PB"))
    if maius >= 6:
        achados.append({"nivel": "ALERTA", "regra": "excesso de maiúsculas", "trecho": "",
                        "porque": "Muitas palavras em caixa alta dão tom de anúncio agressivo."})
    bloqueia = any(a["nivel"] == "BLOQUEIO" for a in achados)
    return {"aprovado": not bloqueia, "achados": achados,
            "resumo": ("Publicação BLOQUEADA até ajuste." if bloqueia else
                       ("Aprovada com alertas para conferência." if achados else "Aprovada: nenhum problema encontrado.")),
            "base": "Provimento CFOAB 205/2021 e capítulo da publicidade do Código de Ética e Disciplina da OAB. "
                    "Conferência automática de apoio; a decisão final é do advogado."}


# ============================================================================ 3. calculadoras

def _num(v, padrao=0.0):
    try:
        return float(str(v).replace(".", "").replace(",", ".")) if isinstance(v, str) and "," in v else float(v)
    except (TypeError, ValueError):
        return padrao


def _data(v):
    return datetime.date.fromisoformat(str(v)[:10])


def salario_minimo():
    return _num(base40.ajuste("r230_salario_minimo"), SALARIO_MINIMO_PADRAO) or SALARIO_MINIMO_PADRAO


def calc_bpc(c):
    renda = _num(c.get("renda_familiar"))
    pessoas = max(1, int(_num(c.get("pessoas"), 1)))
    sm = _num(c.get("salario_minimo"), 0) or salario_minimo()
    per = renda / pessoas
    lim = sm / 4
    return {"renda_per_capita": round(per, 2), "limite_um_quarto": round(lim, 2), "salario_minimo": sm,
            "dentro_do_limite": per <= lim,
            "leitura": ("A renda por pessoa está dentro de 1/4 do salário mínimo." if per <= lim else
                        "A renda por pessoa passa de 1/4 do salário mínimo. Ainda assim, há situações em que a "
                        "Justiça admite outros meios de provar a vulnerabilidade; cada caso exige análise."),
            "aviso": "Estimativa informativa. O INSS e a Justiça analisam a composição do grupo familiar, despesas e laudos."}


def calc_prescricao(c):
    fim = _data(c.get("data_saida"))
    hoje = datetime.date.today()
    limite = fim.replace(year=fim.year + 2) if not (fim.month == 2 and fim.day == 29) else datetime.date(fim.year + 2, 2, 28)
    ajuiz = min(hoje, limite)
    inicio_5 = ajuiz.replace(year=ajuiz.year - 5) if not (ajuiz.month == 2 and ajuiz.day == 29) else datetime.date(ajuiz.year - 5, 2, 28)
    return {"prazo_final_para_ajuizar": limite.isoformat(), "dias_restantes": (limite - hoje).days,
            "periodo_cobravel_desde": inicio_5.isoformat(),
            "leitura": ("Ainda dentro do prazo de 2 anos após a saída." if limite >= hoje else
                        "O prazo de 2 anos após a saída parece ter passado; há exceções que precisam de análise."),
            "base": "Constituição Federal, art. 7º, XXIX: 2 anos após o fim do contrato, alcançando os últimos 5 anos.",
            "aviso": "Estimativa. Interrupções (como protesto judicial ou ação anterior) podem mudar a contagem."}


def _mais_meses(d, n):
    import calendar
    m = d.month - 1 + n
    a, m = d.year + m // 12, m % 12 + 1
    return datetime.date(a, m, min(d.day, calendar.monthrange(a, m)[1]))


def _aniversario(adm, ano):
    return _mais_meses(datetime.date(adm.year, adm.month, 1), (ano - adm.year) * 12).replace(
        day=min(adm.day, __import__("calendar").monthrange(ano, adm.month)[1]))


def calc_rescisao(c):
    sal = _num(c.get("salario"))
    adm, sai = _data(c.get("admissao")), _data(c.get("saida"))
    tipo = (c.get("tipo") or "sem_justa_causa").lower()
    aviso_trab = bool(c.get("aviso_trabalhado"))
    ferias_vencidas = int(_num(c.get("ferias_vencidas"), 0))
    fgts_saldo = _num(c.get("saldo_fgts"), 0)
    if sai < adm:
        raise ValueError("A data de saída é anterior à admissão.")
    anos = sai.year - adm.year - (1 if (sai.month, sai.day) < (adm.month, adm.day) else 0)
    dias_aviso = min(90, 30 + 3 * anos) if tipo in ("sem_justa_causa", "rescisao_indireta") else 0
    projecao = sai + datetime.timedelta(days=0 if aviso_trab else dias_aviso)
    saldo = sal / 30 * sai.day
    # meses do 13º no ano da saida (fracao >= 15 dias conta mes), com projecao do aviso
    m13 = projecao.month - (0 if projecao.day >= 15 else 1)
    if adm.year == projecao.year:
        m13 = m13 - adm.month + (1 if adm.day <= 15 else 0)
    m13 = max(0, min(12, m13))
    # ferias proporcionais: meses desde o ultimo aniversario do contrato; fracao de 15 dias ou mais conta mes
    aniv = _aniversario(adm, projecao.year)
    if aniv > projecao:
        aniv = _aniversario(adm, projecao.year - 1)
    aniv = max(aniv, adm)
    mf = 0
    while _mais_meses(aniv, mf + 1) <= projecao + datetime.timedelta(days=1):
        mf += 1
    ref = _mais_meses(aniv, mf)
    if (projecao - ref).days + 1 >= 15:
        mf += 1
    mf = max(0, min(12, mf))
    itens = []
    itens.append(("Saldo de salário (%d dias)" % sai.day, saldo))
    if dias_aviso and not aviso_trab:
        itens.append(("Aviso prévio indenizado (%d dias)" % dias_aviso, sal / 30 * dias_aviso))
    if tipo != "justa_causa":
        itens.append(("13º salário proporcional (%d/12)" % m13, sal / 12 * m13))
        itens.append(("Férias proporcionais (%d/12) + 1/3" % mf, sal / 12 * mf * 4 / 3))
    if ferias_vencidas:
        itens.append(("Férias vencidas (%d) + 1/3" % ferias_vencidas, sal * ferias_vencidas * 4 / 3))
    if tipo in ("sem_justa_causa", "rescisao_indireta"):
        meses = max(1, ((projecao - adm).days // 30))
        base_fgts = fgts_saldo or sal * 0.08 * meses
        itens.append(("Multa de 40% do FGTS" + ("" if fgts_saldo else " (estimada pelo salário atual)"), base_fgts * 0.40))
    total = sum(v for _, v in itens)
    return {"itens": [{"descricao": d, "valor": round(v, 2)} for d, v in itens], "total_bruto": round(total, 2),
            "dias_aviso": dias_aviso,
            "aviso": "Estimativa bruta, sem descontos de INSS e IR, sem horas extras, adicionais ou diferenças. "
                     "Os valores reais dependem dos documentos (contracheques, extrato do FGTS, TRCT)."}


def calcular(c, u=None):
    tipo = (c.get("calculo") or "").lower()
    if tipo == "bpc":
        return calc_bpc(c)
    if tipo == "prescricao":
        return calc_prescricao(c)
    if tipo == "rescisao":
        return calc_rescisao(c)
    raise ValueError("Cálculo desconhecido. Use bpc, prescricao ou rescisao.")


# ============================================================================ rotas

def get(r, q, u=None):
    if r == "v2/r230/provedores":
        return {"provedores": provedores(), "pasta": PASTA_VOZ, "salario_minimo": salario_minimo()}
    return None


def post(r, c, u=None):
    c = c or {}
    if r == "v2/r230/narrar":
        return narrar(c, u)
    if r == "v2/r230/publicidade":
        return conferir_publicidade(c.get("texto") or "")
    if r == "v2/r230/calcular":
        return calcular(c, u)
    return None


if __name__ == "__main__":
    import sys
    r = conferir_publicidade(open(sys.argv[1], encoding="utf-8").read() if len(sys.argv) > 1 else sys.stdin.read())
    print(json.dumps(r, ensure_ascii=False, indent=1))
    sys.exit(0 if r["aprovado"] else 2)
