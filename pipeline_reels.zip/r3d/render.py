import sys, base64, time, os, http.server, threading, functools
from playwright.sync_api import sync_playwright
tema, dur, fps, outdir = sys.argv[1], float(sys.argv[2]), int(sys.argv[3]), sys.argv[4]
os.makedirs(outdir, exist_ok=True)
h = functools.partial(http.server.SimpleHTTPRequestHandler, directory=os.path.dirname(os.path.abspath(__file__)))
h.log_message = lambda *a: None
srv = http.server.ThreadingHTTPServer(('127.0.0.1', int(os.environ.get('PORTA','8765'))), h)
threading.Thread(target=srv.serve_forever, daemon=True).start()
with sync_playwright() as p:
    b = p.chromium.launch(executable_path='/opt/pw-browsers/chromium-1243/chrome-linux64/chrome',
        args=['--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'])
    pg = b.new_page(viewport={'width':1080,'height':1920})
    pg.on('console', lambda m: print('console:', m.text))
    pg.goto('http://127.0.0.1:'+os.environ.get('PORTA','8765')+'/cena.html?tema='+tema)
    pg.wait_for_function('window.pronto === true', timeout=60000)
    n = int(dur*fps); t0=time.time()
    ini = int(sys.argv[5]) if len(sys.argv)>5 else 0
    fim = int(sys.argv[6]) if len(sys.argv)>6 else n
    for i in range(ini, min(n,fim)):
        d = pg.evaluate(f'window.renderFrame({i/fps})')
        open(f'{outdir}/f{i:05d}.jpg','wb').write(base64.b64decode(d.split(',')[1]))
        if i%100==0: print(i, round(time.time()-t0,1), flush=True)
    print('total', round(time.time()-t0,1))
    b.close()
